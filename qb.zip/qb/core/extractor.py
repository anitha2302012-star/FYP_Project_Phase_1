"""
AI auto-fill: reads the text of an uploaded question paper PDF and extracts
the metadata fields (department, regulation, academic year, semester, subject
code, subject name, exam type).

Technique: text extraction (pypdf) + tokenised line analysis + pattern-based
information extraction (regular expressions and keyword rules).  It is
rule-based NLP, not a trained model, so it works offline and every decision
can be explained.  The faculty always reviews the filled values before saving.
Scanned (image-only) PDFs contain no text, so nothing can be extracted from them.
"""
import re

from pypdf import PdfReader

ROMAN = {"I": 1, "II": 2, "III": 3, "IV": 4, "V": 5, "VI": 6, "VII": 7, "VIII": 8}
WORDS = {"first": 1, "second": 2, "third": 3, "fourth": 4, "fifth": 5, "sixth": 6,
         "seventh": 7, "eighth": 8}

# (short name stored in the database, pattern that identifies it in the text)
DEPARTMENTS = [
    ("AI&DS", r"artificial\s+intelligence\s+(?:and|&)\s+data\s+science|\bAI\s*&\s*DS\b"),
    ("CSBS", r"computer\s+science\s+(?:and|&)\s+business\s+systems"),
    ("CSE", r"computer\s+science\s+(?:and|&)\s+engineering|\bCSE\b"),
    ("IT", r"information\s+technology"),
    ("ECE", r"electronics\s+(?:and|&)\s+communication"),
    ("EEE", r"electrical\s+(?:and|&)\s+electronics"),
    ("MECH", r"mechanical\s+engineering|\bMECH\b"),
    ("CIVIL", r"civil\s+engineering"),
    ("BME", r"biomedical\s+engineering"),
    ("CHEM", r"chemical\s+engineering"),
]

CODE_RE = re.compile(r"\b(\d{2}[A-Z]{2,4}\d{2,3}[A-Z]?|[A-Z]{2,4}\d{4}[A-Z]?|[A-Z]{2,3}\d{3}[A-Z]?)\b")
MONTHS = {"jan": 1, "feb": 2, "mar": 3, "apr": 4, "may": 5, "jun": 6,
          "jul": 7, "aug": 8, "sep": 9, "oct": 10, "nov": 11, "dec": 12}


def read_text(file_obj, max_pages=2):
    """Return the text of the first pages of a PDF ('' if unreadable or scanned)."""
    try:
        file_obj.seek(0)
        reader = PdfReader(file_obj)
        if reader.is_encrypted:
            try:
                reader.decrypt("")
            except Exception:
                return ""
        parts = [(p.extract_text() or "") for p in reader.pages[:max_pages]]
        return "\n".join(parts)
    except Exception:
        return ""
    finally:
        try:
            file_obj.seek(0)
        except Exception:
            pass


def _lines(text):
    text = text.replace("\xa0", " ")
    out = []
    for raw in text.splitlines():
        line = re.sub(r"[ \t]+", " ", raw).strip()
        if line:
            out.append(line)
    return out


def _find_code(lines):
    def valid(c):
        return not re.fullmatch(r"[A-Z]{1,3}20\d{2}", c)

    for line in lines:                       # 1) a line that mentions "code"
        if re.search(r"\bcode\b", line, re.I):
            for m in CODE_RE.finditer(line):
                if valid(m.group(1)):
                    return m.group(1), line
    for line in lines[:20]:                  # 2) any code near the top
        for m in CODE_RE.finditer(line):
            if valid(m.group(1)):
                return m.group(1), line
    return None, None


def _clean_name(name):
    name = re.split(r"\s{2,}|\b(?:max|maximum|time|marks|date|duration|regulations?|semester|year|"
                    r"dept|department|part|answer)\b", name, maxsplit=1, flags=re.I)[0]
    name = re.sub(r"^[\s\-–:/|()\[\]&.,]+|[\s\-–:/|()\[\]&.,]+$", "", name)
    if name.isupper():
        name = name.title()
    return name[:150].strip()


def _find_name(lines, code, code_line):
    for line in lines:                       # "Subject Name : Operating Systems"
        m = re.search(r"(?:subject|course)\s*(?:name|title)\s*[:\-–]\s*(.+)", line, re.I)
        if m:
            cand = _clean_name(re.sub(re.escape(code or "@@"), "", m.group(1)))
            if len(cand) >= 3:
                return cand
    if code and code_line:                   # "CS3451 - Operating Systems"
        m = re.search(re.escape(code) + r"[\s\-–:/|()&]*(?:name|title)?[\s\-–:/|]*([A-Za-z][A-Za-z &,'/\-]{3,90})",
                      code_line)
        if m:
            cand = _clean_name(m.group(1))
            if len(cand) >= 3 and not re.fullmatch(r"(?i)(name|title|code)", cand):
                return cand
        m = re.search(r"([A-Za-z][A-Za-z &,'\-]{3,90})\s*[(\[]\s*" + re.escape(code), code_line)
        if m:                                # "Operating Systems (CS3451)"
            cand = _clean_name(m.group(1))
            if len(cand) >= 3:
                return cand
    return None


def _find_semester(text):
    m = re.search(r"\b(first|second|third|fourth|fifth|sixth|seventh|eighth)\s+semester\b", text, re.I)
    if m:
        return WORDS[m.group(1).lower()]
    for pat in (r"(?i:semester|sem)\b\s*[:\-–]?\s*(\d|[IVX]{1,4})\b",
                r"\b(\d)(?:st|nd|rd|th)?\s*(?i:semester|sem)\b",
                r"\b([IVX]{1,4})\s*(?i:semester|sem)\b"):
        for m in re.finditer(pat, text):
            v = m.group(1)
            n = int(v) if v.isdigit() else ROMAN.get(v)
            if n and 1 <= n <= 8:
                return n
    return None


def _find_year(text):
    m = re.search(r"\b(20\d{2})\s*[-–—/]\s*(20)?(\d{2})\b", text)
    if m:
        start = int(m.group(1))
        end = int((m.group(2) or "20") + m.group(3))
        if end == start + 1:
            return f"{start}-{end}"
    m = re.search(r"\b(jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)[a-z]*\.?"
                  r"(?:\s*[/&,\-]\s*[A-Za-z]+\.?)?\s*,?\s*(20\d{2})\b", text, re.I)
    if m:                                    # "Nov/Dec 2025" -> academic year 2025-2026
        month, year = MONTHS[m.group(1).lower()], int(m.group(2))
        start = year if month >= 7 else year - 1
        return f"{start}-{start + 1}"
    return None


def _find_regulation(text):
    m = re.search(r"\bR\s*-?\s*(20\d{2})\b", text) or \
        re.search(r"(?i)regulations?\s*[:\-–]?\s*(?:R\s*-?\s*)?(20\d{2})\b", text)
    return f"R{m.group(1)}" if m else None


def _find_exam_type(text):
    t = text.lower()
    m = re.search(r"\b(?:internal\s+assessment(?:\s+test)?|internal\s+test|internal|cat|cycle\s+test|"
                  r"unit\s+test|periodical\s+test|test|assessment)\s*[-:.]?\s*(?:no\.?\s*)?"
                  r"(1|2|ii|i|one|two)\b", t)
    if m:
        return "Internal Test 1" if m.group(1) in ("1", "i", "one") else "Internal Test 2"
    if re.search(r"end\s*semester|semester\s+exam|university\s+exam|\bese\b|final\s+exam", t):
        return "Semester"
    return None


def _find_department(text):
    for short, pat in DEPARTMENTS:
        if re.search(pat, text, re.I):
            return short
    return None


def extract_metadata(file_obj):
    """Return (fields, text_found). fields only contains values that were detected."""
    text = read_text(file_obj)
    if not text.strip():
        return {}, False
    lines = _lines(text)
    flat = "\n".join(lines)
    code, code_line = _find_code(lines)
    fields = {
        "department": _find_department(flat),
        "regulation": _find_regulation(flat),
        "academic_year": _find_year(flat),
        "semester": _find_semester(flat),
        "subject_code": code,
        "subject_name": _find_name(lines, code, code_line),
        "exam_type": _find_exam_type(flat),
    }
    return {k: v for k, v in fields.items() if v not in (None, "")}, True
