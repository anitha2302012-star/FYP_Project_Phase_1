# QB (Question Bank) - AI-Enabled Question Paper Portal (Django + PostgreSQL)

Login with **email + password**. Three roles:
- **Admin** - manages users, all question papers, and sees the analytics dashboard (uploads, downloads, views, activity log).
- **Faculty** - uploads Internal Test 1, Internal Test 2 and Semester question papers (PDF). Manages own uploads.
- **Student** - searches (keyword + filters), views and downloads PDFs.

Supported exam types: **Internal Test 1, Internal Test 2, Semester Exam** (no model exam, no third test).

## The AI feature: auto-fill from the PDF
When faculty choose a PDF on the Upload page, QB reads the text of its first two pages and fills in:
department, regulation, academic year, semester, subject code, subject name and exam type.
Filled boxes turn green and the faculty checks them before clicking Upload.

How it works (explain this in the review):
1. **Text extraction** - `pypdf` reads the text layer of the PDF.
2. **Tokenising into lines** - the text is cleaned and split into lines and words.
3. **Pattern-based information extraction** - regular expressions and keyword rules find each field
   (for example `CS3451` = subject code pattern, `Semester V` / `Third Semester` = semester, `CAT 1` / `Internal Test II` = Internal Test 1/2,
   `Nov/Dec 2025` = academic year 2025-2026, `Computer Science and Engineering` = CSE).
4. **Human check** - the values are only suggestions; nothing is saved until the faculty submits the form.

Code: `core/extractor.py` (the logic), the `extract` view in `core/views.py` (the web address `/upload/extract/`),
and the JavaScript at the bottom of `core/templates/core/upload.html` (calls it when a file is chosen).

Honest limits: this is rule-based NLP, not a trained deep-learning model. It works on PDFs that contain real text.
Scanned image PDFs have no text, so the page shows a message and the faculty types the details by hand.
Papers with an unusual layout may fill only some boxes.
Try it with the PDFs in the `sample_papers/` folder.

## Theme (and why): dark black-to-green gradient
A diagonal gradient from black through deep forest green to a brighter green glow. Dark backgrounds reduce glare
for long reading sessions, and green reads as "found it / go", which suits a search portal. Cards are
semi-transparent dark panels so the gradient shows through.

**Where to change the look:** open `core/templates/core/base.html` and edit the colour variables at the top of the
`<style>` block (`--bg-1`, `--bg-2`, `--bg-3` are the gradient, `--accent` is the green of buttons and links).
The login page's extra glow is the `.login-wrap` lines at the bottom of that same `<style>` block; the page itself is
`core/templates/core/login.html`.

## Run in VS Code
```
python -m venv venv
venv\Scripts\activate
pip install -r requirements.txt
```
**PostgreSQL:** create a NEW empty database in pgAdmin named `paperlensdb` (do not reuse the old `qpdb`,
because the exam types changed), then in the same terminal (PowerShell):
```
$env:DB_NAME="paperlensdb"
$env:DB_USER="postgres"
$env:DB_PASSWORD="yourpass"
$env:DB_HOST="localhost"
```
For quick testing you can skip these four lines and Django uses SQLite.

Then:
```
python manage.py makemigrations core
python manage.py migrate
python manage.py seed_demo
python manage.py runserver
```
Open http://127.0.0.1:8000/

| Role | Email | Password |
|---|---|---|
| Admin | admin@paperlens.com | admin123 |
| Faculty | faculty@paperlens.com | faculty123 |
| Student | student@paperlens.com | student123 |

Change these passwords (Admin > Users > Edit) before real use.

## Structure
`config/` settings + urls, `core/models.py` (User, Paper, ActivityLog), `core/views.py`, `core/forms.py`,
`core/extractor.py` (AI auto-fill), `core/templates/core/` (Bootstrap 5 pages), `sample_papers/` (test PDFs).

## Name and logo
The site is called **QB** (short for Question Bank). The logo is a QB monogram: a rounded green square holding a
"Q" (its tail doubles as a pointer) next to a "B". It is pure SVG shapes, so it needs no image file and no fonts.
- Logo drawing: `core/templates/core/_logo.html` (used in the navbar and on the login page)
- Browser-tab icon: the `<link rel="icon" ...>` line in `core/templates/core/base.html`
- Name text: the `<title>`, the navbar brand and `login.html`
